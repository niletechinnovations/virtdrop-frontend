//import TemplatePreview from './views/Pages/Frontend/TemplatePreview';
//import StartInspection from './views/Pages/Frontend/StartInspection';

const commonRoutes = [
  // { path: '/common/template/:templateId', exact: true, name: 'Template Preview', component: TemplatePreview },
  // { path: '/common/inspection/:inspectionId', exact: true, name: 'Inspection', component: StartInspection },
];

export default commonRoutes;
