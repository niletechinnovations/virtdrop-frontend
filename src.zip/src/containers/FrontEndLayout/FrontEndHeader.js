import React from 'react';
import {Link} from 'react-router-dom';
import logo from './../../assets/images/logo.png';
import { Collapse, Navbar, NavbarToggler, Nav, NavItem, Dropdown, DropdownItem, DropdownToggle, DropdownMenu } from 'reactstrap';

import commonService from '../../core/services/commonService';
import './FrontEndHeader.css';
import UserAvtar from '../UserLayout/UserAvtar'

class FrontEndHeader extends React.Component {
  constructor(props){
      super(props);
      this.state = {
        collapseID: false,
        isLoggedOut: false,
        toggleActive: false,
        dropdownOpen: false,
        setDropdownOpen: false
      }
    this.onToggle = this.onToggle.bind(this);
    this.toggleUserMenu = this.toggleUserMenu.bind(this);

  }
  onToggle() {
    this.setState({ toggleActive: !this.state.toggleActive });
  }
  
  logoutUser() {
    localStorage.clear();
    this.setState({isLoggedOut:true});
  };

  toggleUserMenu = () => {
    this.setState({ dropdownOpen: !this.state.dropdownOpen });
  }
  

  render(){
   
    let  headerItem = '';
    if(commonService.getAuth()) {
      headerItem = <>
      <Dropdown nav isOpen={this.state.dropdownOpen} toggle={this.toggleUserMenu} className="user-menu">
        <DropdownToggle nav caret>
          <div className="user-name"><span><UserAvtar /></span>Hi, {localStorage.getItem( 'userName' )}!</div>
        </DropdownToggle>
        <DropdownMenu>
          { (localStorage.getItem( 'role' ).toLowerCase() === "organization" || localStorage.getItem( 'role' ).toLowerCase() === "admin" ) && 
          <DropdownItem><Link to={ (localStorage.getItem( 'role' ).toLowerCase() === "admin") ? `/admin/dashboard` : `/user/dashboard` } ><i className="fa fa-dashboard"></i> Dashboard</Link></DropdownItem>
          }
          { (localStorage.getItem( 'role' ).toLowerCase() === "organization" || localStorage.getItem( 'role' ).toLowerCase() !== "admin" ) && 
            <DropdownItem><Link to={ (localStorage.getItem( 'role' ).toLowerCase() === "organization") ? `/user/my-profile` : `/advertiser/profile` } ><i className="fa fa-user"></i> My Profile</Link></DropdownItem>
          }
          { localStorage.getItem( 'role' ).toLowerCase() === "organization"  && 
            <DropdownItem><Link to="/user/manage-request"><i className="fa fa-list-ul"></i> Manage Request</Link></DropdownItem>
          }
          { (localStorage.getItem( 'role' ).toLowerCase() === "organization" || localStorage.getItem( 'role' ).toLowerCase() !== "admin" ) && 
            <DropdownItem><Link to="/user/change-password"><i className="fa fa-key"></i> Change Password</Link></DropdownItem>
          }
          <DropdownItem><Link to= "/" onClick={() => this.logoutUser()}><i className="fa fa-sign-out"></i> Log Out</Link></DropdownItem>
        </DropdownMenu>
      </Dropdown>
      
      </>
      }
      else {
      headerItem = <>
        <NavItem>
          <Link to="/login">Login/Register</Link>
        </NavItem>
        <NavItem>
          <Link className="Sell-btn" to="/register">Hire an Assistant <i className="fa fa-angle-right"></i></Link>
        </NavItem>
      </>
    }

    

    return (
      
      <header className="header">
        <div className="top-header">
          <div className="container">
            <div className="row">
              <div className="col-md-3">
                <div className="header-contact-card">
                  <div className="header-contact-icon">
                    <img src="/images/mail.svg" alt="" />
                  </div>
                  <div className="header-contact-content">
                    <p>Eamil Address</p>
                    <h2><a href="mailto:support@virtdrop.com">support@virtdrop.com</a></h2>
                  </div>
                </div>
              </div>

              <div className="col-md-3">
                <div className="header-contact-card">
                  <div className="header-contact-icon">
                    <img src="/images/phone.svg" alt="phone" />
                  </div>
                  <div className="header-contact-content">
                    <p>Phone Number</p>
                    <h2><a href="tel:+22140 006754">+22 140 006 754</a></h2>
                  </div>
                </div>
              </div>

              <div className="col-md-3">
                <div className="header-contact-card">
                  <div className="header-contact-icon">
                    <img src="/images/location.svg" alt="Location" />
                  </div>
                  <div className="header-contact-content">
                    <p>Office Address</p>
                    <h2>576 Fifth Avenue,New York</h2>
                  </div>
                </div>
              </div>

              <div className="col-md-3">
                <div className="header-social">
                  <ul>
                    <li><a href="https://www.facebook.com/" ><i className="fa fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/" target="_blank" rel="noopener noreferrer"><i className="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.linkedin.com/" target="_blank" rel="noopener noreferrer"><i className="fa fa-linkedin"></i></a></li>
                    <li><a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer"><i className="fa fa-instagram"></i></a></li>
                  </ul>
                </div>
              </div>
				    </div>
				
		    	</div>
        </div>
        <div className="bottom-header">
          <div className="container">
            <div className="header-navigation">
              <Navbar expand="lg">
                <div className="navbar-brand">
                  <Link to="/"><img src={logo} height="60" alt="Logo" /></Link>
                </div>
                <NavbarToggler onClick={this.onToggle} data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" />
                <Collapse isOpen={this.state.toggleActive} navbar className="justify-content-end" id="navbarSupportedContent">
                  <Nav className="navbar-nav" navbar>
                    <NavItem>
                      <Link to="/how-it-works">How it Works?</Link>
                    </NavItem>
                    <NavItem>
                      <Link to="/services">Services</Link>
                    </NavItem>
                    <NavItem>
                      <Link to="/pricing">Pricing</Link>
                    </NavItem>
                    <NavItem>
                      <Link to="/contact-us">Contact Us</Link>
                    </NavItem>
                  </Nav>  

                  <Nav className="navbar-nav ml-auto" navbar>
                  
                    {headerItem}

                  </Nav>
                </Collapse>
              </Navbar>
            </div>
          </div>  
        </div>
      </header>  
    )
  };
}

export default FrontEndHeader;